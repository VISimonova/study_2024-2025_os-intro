﻿Прохождение внешнего курса![](Aspose.Words.9b85aa71-b03e-4844-beed-edccd6fda5e5.001.png)

Защита пк/телефона

Симонова В.И. 04 мая 2025

Российский университет дружбы народов, Москва, Россия НКАбд-04-23

Докладчик![](Aspose.Words.9b85aa71-b03e-4844-beed-edccd6fda5e5.002.png)

- Симонова Виктория Игоревна ![](Aspose.Words.9b85aa71-b03e-4844-beed-edccd6fda5e5.003.png)
- Студент 
- НКАбд-04-23 
- Российский университет дружбы народов 
- [1132236012@pfur.ru](mailto:1132237371@rudn.ru) 

Цели и задачи![](Aspose.Words.9b85aa71-b03e-4844-beed-edccd6fda5e5.004.png)

Проработать задания, которые касаются защиты устройств

3/20

<a name="_page3_x0.00_y0.48"></a>[Выполнение лабораторной работы](#_page3_x0.00_y0.48)![](Aspose.Words.9b85aa71-b03e-4844-beed-edccd6fda5e5.005.png)


Шифровка загрузочного сектора диска![ref1]

![](Aspose.Words.9b85aa71-b03e-4844-beed-edccd6fda5e5.007.jpeg)

Рис. 1: Задание 1

Шифрование диска![ref1]

![](Aspose.Words.9b85aa71-b03e-4844-beed-edccd6fda5e5.008.jpeg)

Рис. 2: Задание2

Программы,жифрующие жесткий диск![ref1]

![](Aspose.Words.9b85aa71-b03e-4844-beed-edccd6fda5e5.009.jpeg)

Рис. 3: Задание3

Стойкие пароли![ref1]

![](Aspose.Words.9b85aa71-b03e-4844-beed-edccd6fda5e5.010.jpeg)

Рис. 4: Задание 4

Где безопасно хранить пароли![ref1]

![](Aspose.Words.9b85aa71-b03e-4844-beed-edccd6fda5e5.011.jpeg)

Рис. 5: Задание5

Задача капчи![ref1]

![](Aspose.Words.9b85aa71-b03e-4844-beed-edccd6fda5e5.012.jpeg)

Рис. 6: Задание 6

Зачем нужно хэширование паролей![ref1]

![](Aspose.Words.9b85aa71-b03e-4844-beed-edccd6fda5e5.013.jpeg)

Рис. 7: Задание 7

Атака протоколов перебором![ref1]

![](Aspose.Words.9b85aa71-b03e-4844-beed-edccd6fda5e5.014.jpeg)

Рис. 8: Задание 8

Меры безопасности![ref1]

![](Aspose.Words.9b85aa71-b03e-4844-beed-edccd6fda5e5.015.jpeg)

Рис. 9: Задание 9

Фишинговые ссылки![ref1]

![](Aspose.Words.9b85aa71-b03e-4844-beed-edccd6fda5e5.016.jpeg)

Рис. 10: Задание 10

Фишинговый email![ref1]

![](Aspose.Words.9b85aa71-b03e-4844-beed-edccd6fda5e5.017.jpeg)

Рис. 11: Задание 11

Email Спуфинг![ref1]

![](Aspose.Words.9b85aa71-b03e-4844-beed-edccd6fda5e5.018.jpeg)

Рис. 12: Задание 12

Троян![ref1]

![](Aspose.Words.9b85aa71-b03e-4844-beed-edccd6fda5e5.019.jpeg)

Рис. 13: Задание 13

Протокол мессенджеров Signal![ref1]

![](Aspose.Words.9b85aa71-b03e-4844-beed-edccd6fda5e5.020.jpeg)

Рис. 14: Задание 14

Суть сквозного шифрования![ref1]

![](Aspose.Words.9b85aa71-b03e-4844-beed-edccd6fda5e5.021.jpeg)

Рис. 15: Задание 15

![ref1]

Выводы![](Aspose.Words.9b85aa71-b03e-4844-beed-edccd6fda5e5.022.png)

Проделаны задания,связаные с защитой устройств

[ref1]: Aspose.Words.9b85aa71-b03e-4844-beed-edccd6fda5e5.006.png
